<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Unit extends Model
{
    use HasFactory;
    use SoftDeletes;


    public function unit_type(){
        return $this->hasOne('App\Models\UnitType','id','unittype_id');
    }

    public function owner(){
        return $this->hasOne('App\Models\User','id','owner_id');
    }

    public function argument(){
        return $this->hasOne('App\Models\Agreement','unit_id','id');
    }

    public function city(){
        return $this->hasOne('App\Models\City','id','city_id');
    }
    public function flats(){
        return $this->hasMany('App\Models\Flat','unit_id','id');
    }
}
